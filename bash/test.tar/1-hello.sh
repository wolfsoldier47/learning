#!/bin/bash

echo "hello world"

cat >> testin.txt