!/bin/bash

uniq -c -i | sed 's/^\s*/''/g'#
