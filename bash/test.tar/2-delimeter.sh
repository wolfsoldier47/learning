#!/bin/bash


cat << EOF

This will be our new output
EOF